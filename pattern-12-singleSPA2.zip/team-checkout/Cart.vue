<template>
  <div>
    <router-link to="/">&lt; home</router-link>&nbsp;-
    <router-link to="/checkout/pay">pay &gt;</router-link>
    <h1>🛒 Cart</h1>
    <router-link to="/product/eicher">
      Eicher Diesel 215/16
      <br />
      <img src="https://mi-fr.org/img/eicher.svg" width="100" />
    </router-link>
  </div>
</template>
