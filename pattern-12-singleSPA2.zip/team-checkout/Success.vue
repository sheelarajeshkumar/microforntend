<template>
  <div>
    <router-link to="/">home</router-link>
    <h1>🥳 Success</h1>
  </div>
</template>
