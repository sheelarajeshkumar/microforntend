<template>
  <div>
    <router-link to="/checkout/cart">&lt; cart</router-link>&nbsp;-
    <router-link to="/checkout/success">buy now &gt;</router-link>
    <h1>💵 Pay</h1>
  </div>
</template>
