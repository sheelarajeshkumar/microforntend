<template>
  <div id="app-checkout">
    <router-view></router-view>
  </div>
</template>
